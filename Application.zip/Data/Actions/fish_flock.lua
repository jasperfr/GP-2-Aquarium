fish_flock = function(entity)
    local shark = game:GetEntitiesByTagName("shark")[0]
    if Vector2.Distance(entity.Position, shark.Position) < 200 then
        entity:AddForce(Behaviours.Flee(entity, shark.Position))
    end

    local flock = game:GetEntitiesByTagName("fish")
    entity:AddForce(Behaviours.Flock(entity, flock))
end