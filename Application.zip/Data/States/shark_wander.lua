state_sharkwander = State()

state_sharkwander.Enter = function()
	local entity = state_sharkwander.Handle.Entity

    -- Create a new starting target vector.
    local target_vector = Vector2(math.random(1280), math.random(720))
    entity:SetLocal("Target", target_vector)
end

state_sharkwander.Execute = function()
	local entity = state_sharkwander.Handle.Entity
    local position = entity.Position
    
    -- Move to the target, or set a new target if the shark is near.
    local target_vector = entity:GetLocal("Target")
    if Vector2.Distance(position, target_vector) < 20 then
        target_vector = Vector2(math.random(1280), math.random(720))
        entity:SetLocal("Target", target_vector)
    end
	entity:AddForce(Behaviours.Arrive(entity, target_vector))

    -- The shark gets hungry with each game tick
	local hunger = entity:GetLocal("Hunger")
	hunger = hunger - 0.02
    entity:SetLocal("Hunger", hunger)

end

state_sharkwander.Exit = function()
    
end