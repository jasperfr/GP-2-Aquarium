﻿-- Main application logic for the game.
-- Game : World class. Contains world data.
import ('Aquarium', 'Aquarium')
import ('System.Numerics')
require 'Data/States/shark_wander'
require 'Data/Actions/fish_flock'

-- Randomize seed.
math.randomseed(os.time())

-- Create the shark object.
shark = GameObject("Jasper", "shark", 10, 10)
shark:SetLocal("Health", 100)
shark:SetLocal("Hunger", 50)
shark.Mass = 50.0
shark.MaxSpeed = 4.5
shark.Size = 20.0
game:AddEntity(shark)

-- Create the fishes.
for i = 0, 199 do
	local fish = GameObject("Guppy", "fish", math.random(1280), math.random(720))
	fish:SetLocal("Health", 100)
	fish.Mass = 20.0
	fish.MinSpeed = 2.0
	fish.MaxSpeed = 3.5
	fish.Size = 10.0
	fish:AddAction(fish_flock)
	game:AddEntity(fish)
end

-- Create the shark state machine.
sm_shark = StateMachine(shark)
sm_shark:SetState(state_sharkwander)
game:AddStateMachine(sm_shark)

-- Start the game already!
game:SetTickSpeed(5)
game:Start()

return "LUA OK!"