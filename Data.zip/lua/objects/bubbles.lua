bubbles_float = function(entity)
    local sin = entity:GetLocal("sinoid")
    sin = sin + 0.01
    entity:SetLocal("sinoid", sin)

    local vector = entity.Position
    entity.Position = Vector2(vector.X + math.sin(sin), vector.Y - entity:GetLocal("vspeed"))
end

bubbles = GameObject()
bubbles:SetLocal("vspeed", 3)
bubbles:SetLocal("sinoid", 0.2)
bubbles.Size = 24.0
bubbles.BaseSprite = spr_bubbles
bubbles:AddAction(bubbles_float)
game:AddObject("obj_bubbles", bubbles)