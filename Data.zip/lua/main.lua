import ('Aquarium', 'Aquarium')
import ('System.Numerics')
import ('System.Math')
require 'sprites'
require 'objects/shark'
require 'objects/bubble'
require 'objects/bubbles'
require 'objects/fish'

math.randomseed(os.time())

local bg = GameObject()
game:AddObject("obj_bg", bg)

bg.Size = 720

-- Make small bubbles
for i = 0, 19 do
    local bubbles = game:CreateInstance("obj_bubbles", math.random(1280), math.random(720))
    bubbles:SetLocal("vspeed", math.random() * 5)
    bubbles.Size = bubbles:GetLocal("vspeed") * 10
end

-- Make big bubbles
for i = 0, 19 do
    local bubble = game:CreateInstance("obj_bubble", math.random(1280), math.random(720))
    bubble:SetLocal("vspeed", math.random() * 5)
    bubble.Size = bubbles:GetLocal("vspeed") * 10
end

-- Make sharks
game:CreateInstance("obj_shark", 24, 24, EStateMachine(state_sharkwander))
game:CreateInstance("obj_shark", 76, 76, EStateMachine(state_sharkwander))

-- Make fish
for i = 0, 99 do
    local fish = game:CreateInstance("obj_fish", math.random(1280), math.random(720))
    fish.Size = 48 + math.random() * 4
end

game:SetSpatialGridSize(32);
game:SetTickSpeed(5)
game:Start()

return "LUA OK!"