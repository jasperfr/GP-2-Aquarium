-- The shark has nothing else to do than to wait to die.

state_sharkidle = State()

state_sharkidle.Enter = function()

end

state_sharkidle.Execute = function()

end

state_sharkidle.Exit = function()

end