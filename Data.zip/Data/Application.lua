﻿-- Main application logic for the game.
-- Game : World class. Contains world data.
import ('Aquarium', 'Aquarium')
import ('System.Numerics')
require 'Data/States/shark_wander'
require 'Data/States/shark_hunt'
require 'Data/States/shark_idle'
require 'Data/Actions/fish_flock'
require 'Data/Actions/shark_starve'

GRID_SIZE = 24

-- Randomize seed.
math.randomseed(os.time())

-- Create sprites.
spr_fish_right = Sprite()
spr_fish_right:AddImage("Data/Sprites/fish_0_0.png")
spr_fish_right:AddImage("Data/Sprites/fish_0_1.png")
spr_fish_right:AddImage("Data/Sprites/fish_0_2.png")
spr_fish_right.ImageSpeed = 0.1
game:AddSprite("spr_FishRight", spr_fish_right)

spr_fish_left = Sprite()
spr_fish_left:AddImage("Data/Sprites/fish_2_0.png")
spr_fish_left:AddImage("Data/Sprites/fish_2_1.png")
spr_fish_left:AddImage("Data/Sprites/fish_2_2.png")
spr_fish_left.ImageSpeed = 0.1
game:AddSprite("spr_FishLeft", spr_fish_left)

spr_shark = Sprite()
spr_shark:AddImage("Data/Sprites/shark_0.png")
spr_shark:AddImage("Data/Sprites/shark_1.png")
spr_shark:AddImage("Data/Sprites/shark_2.png")
spr_shark.ImageSpeed = 0.1
game:AddSprite("spr_Shark", spr_shark)

-- Create the shark object.
for i = 0,3 do
	local shark = GameObject("Jasper", "shark", 10, 10 + 10 * i)
	shark:SetLocal("Health", 100)
	shark:SetLocal("Hunger", 15)
	shark.Mass = 50.0
	shark.MaxSpeed = 4.5
	shark.Size = 20.0
	shark.BaseSprite = spr_shark
	shark:AddAction(shark_starve)
	game:AddEntity(shark)
	
	local sm_shark = StateMachine(shark)
	sm_shark:SetState(state_sharkwander)
	game:AddStateMachine(sm_shark)
end

-- Create the fishes.
for i = 0,499 do
	local fish = GameObject("Guppy", "fish", math.random(1280), math.random(720))
	fish:SetLocal("Health", 100)
	fish.Mass = 20.0
	fish.MinSpeed = 2.0
	fish.MaxSpeed = 3.5
	fish.Size = 10.0
	fish.BaseSprite = spr_fish_left
	fish:AddAction(fish_flock)
	game:AddEntity(fish)
end

-- Create the shark state machine.

-- Start the game already!
game:SetSpatialGridSize(GRID_SIZE);
game:SetTickSpeed(5)
game:Start()

return "LUA OK!"